package test;

import org.springframework.stereotype.Component;

@Component
public class SpringTest2 {
    public SpringTest2() {
        System.out.println("SpringTest2 instance created");
    }

}
